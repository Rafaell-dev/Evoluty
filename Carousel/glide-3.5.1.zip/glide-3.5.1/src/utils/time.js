/**
 * Returns a current time.
 *
 * @return {Number}
 */
export function now () {
  return new Date().getTime()
}
